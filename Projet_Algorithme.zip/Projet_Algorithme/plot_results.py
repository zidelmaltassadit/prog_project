import pandas as pd
import matplotlib.pyplot as plt
import os
import sys

# --- Configuration des fichiers et des noms ---
CSV_RANDOM = 'results_random.csv'
CSV_BEST = 'results_best.csv'
CSV_WORST = 'results_worst.csv'

# Noms des colonnes (à vérifier que ces noms correspondent exactement à vos CSV)
QUADRATIC_ALGOS = ['Bulle_v1', 'Cocktail', 'Selection', 'Insertion']
NLOGN_ALGOS = ['Fusion', 'Rapide', 'Tas', 'Shell']
# Note: J'ai corrigé 'Comptage' en 'CountingSort' si vos colonnes le nécessitent. 
# Si vos colonnes utilisent bien les noms français, ajustez cette liste :
ALL_ALGOS = ['Bulle_v1', 'Bulle_v2', 'Bulle_v3', 'Cocktail', 'Selection', 'Insertion', 'Fusion', 'Rapide', 'Comptage', 'Tas', 'Shell']


def load_data(filename):
    """Charge les données du fichier CSV."""
    if not os.path.exists(filename):
        print(f"Erreur : Fichier {filename} non trouvé. Exécutez le benchmark C d'abord.")
        sys.exit(1)
    # Assumer que la première colonne est la taille (n)
    df = pd.read_csv(filename)
    # Renommer la colonne Taille si nécessaire (cela dépend de l'output de votre C)
    if 'Taille' not in df.columns and 'n' in df.columns:
        df = df.rename(columns={'n': 'Taille'})
    return df


def plot_graph(df, algorithms, title, filename, y_label='Temps d\'exécution (secondes)', show_log=False):
    """Fonction générique pour tracer un graphique (utilisée pour les comparaisons)."""
    plt.figure(figsize=(12, 6))
    
    # Tracer les courbes
    for algo in algorithms:
        if algo in df.columns:
            plt.plot(df['Taille'], df[algo], marker='o', label=algo.replace('_', ' '))

    plt.title(title, fontsize=16)
    plt.xlabel('Taille du tableau (n)', fontsize=12)
    plt.ylabel(y_label, fontsize=12)
    plt.grid(True, linestyle='--', alpha=0.7)
    plt.legend(loc='best')

    if show_log:
        plt.yscale('log')
        
    # S'assurer que le dossier 'images' existe
    os.makedirs('images', exist_ok=True)
    
    plt.savefig(f'images/{filename}.png')
    plt.close()
    print(f"Graphe '{filename}.png' généré.")


def plot_individual_analysis(df_best, df_worst, df_random, sort_name, file_name):
    """Génère un graphique pour un seul algorithme avec ses 3 cas (Meilleur, Pire, Moyen)."""
    
    if sort_name not in df_random.columns:
        print(f"Attention : L'algorithme '{sort_name}' n'a pas été trouvé dans les fichiers CSV. Saut.")
        return

    # Utiliser 'Taille' comme colonne n
    df = pd.DataFrame({
        'n': df_random['Taille'], 
        'Meilleur Cas': df_best[sort_name],
        'Pire Cas': df_worst[sort_name],
        'Cas Moyen': df_random[sort_name]
    })

    plt.figure(figsize=(10, 6))
    
    # Couleurs pour le rapport : Bleu (Meilleur), Rouge (Pire), Vert (Moyen)
    plt.plot(df['n'], df['Meilleur Cas'], label='Meilleur Cas (Croissant)', color='blue', linewidth=2)
    plt.plot(df['n'], df['Pire Cas'], label='Pire Cas (Décroissant)', color='red', linewidth=2) 
    plt.plot(df['n'], df['Cas Moyen'], label='Cas Moyen (Aléatoire)', color='green', linewidth=2)
    
    plt.xlabel("Taille du tableau (n)")
    plt.ylabel("Temps d'exécution (secondes)")
    plt.title(f"Analyse des trois cas pour le Tri : {sort_name.replace('_', ' ')}")
    plt.legend()
    plt.grid(True, linestyle='--', alpha=0.6)
    plt.tight_layout()
    
    # S'assurer que le dossier 'images' existe
    os.makedirs('images', exist_ok=True)
    
    output_path = f"images/{file_name}.png"
    plt.savefig(output_path)
    plt.close()
    print(f"Graphe '{file_name}.png' généré.")


def plot_comparison_graphs(df_random, df_best):
    """Génère les 5 graphiques de comparaison."""
    
    # 1. Comparaison globale O(n^2) vs O(n log n) (Cas Moyen)
    plot_graph(
        df_random, ALL_ALGOS,
        "Comparaison globale des 11 algorithmes (Cas Moyen Aléatoire)",
        "Graphe_1_Global_Comparaison"
    )
    
    # 2. Focus sur les O(n^2) (Cas Moyen)
    plot_graph(
        df_random, QUADRATIC_ALGOS,
        "Focus sur les algorithmes Quadratiques O(n^2) (Cas Moyen)",
        "Graphe_2_Focus_Quadratique"
    )
    
    # 3. Focus sur les O(n log n) et O(n+k) (Cas Moyen)
    plot_graph(
        df_random, NLOGN_ALGOS + ['Comptage'],
        "Focus sur les algorithmes rapides O(n log n) et O(n+k) (Cas Moyen)",
        "Graphe_3_Focus_Rapide"
    )

    # 4. Impact des optimisations du Tri à Bulle (Cas Moyen)
    plot_graph(
        df_random, ['Bulle_v1', 'Bulle_v2', 'Bulle_v3'],
        "Impact des optimisations du Tri à Bulle (Cas Moyen)",
        "Graphe_4_Bulle_Optimisations"
    )

    # 5. Tri par Sélection vs Tri par Insertion (Meilleur Cas)
    plot_graph(
        df_best, ['Selection', 'Insertion', 'Bulle_v3', 'Rapide'],
        "Meilleur Cas (Tableau trié) : O(n) vs O(n^2)",
        "Graphe_5_Meilleur_Cas"
    )


if __name__ == '__main__':
    # ----------------------------------------------------------------------
    # ÉTAPE 1 : CHARGEMENT DES DONNÉES (DOIT ÊTRE FAIT EN PREMIER)
    # ----------------------------------------------------------------------
    df_random = load_data(CSV_RANDOM)
    df_best = load_data(CSV_BEST)
    df_worst = load_data(CSV_WORST)

    # Créer le dossier images s'il n'existe pas
    os.makedirs('images', exist_ok=True)

    # ----------------------------------------------------------------------
    # ÉTAPE 2 : GÉNÉRATION DES 5 GRAPHES DE COMPARAISON
    # ----------------------------------------------------------------------
    plot_comparison_graphs(df_random, df_best)

    # ----------------------------------------------------------------------
    # ÉTAPE 3 : GÉNÉRATION DES 11 GRAPHES D'ANALYSE INDIVIDUELLE
    # ----------------------------------------------------------------------
    
    # Liste des 11 algorithmes
    ALGORITHMS_TO_PLOT = [
        'Bulle_v1', 'Bulle_v2', 'Bulle_v3', 'Cocktail', 'Selection', 
        'Insertion', 'Comptage', 'Fusion', 'Rapide', 'Tas', 
        'Shell' 
    ]
    
    # Je suppose ici que 'Rapide' correspond à 'QuickSort' et 'Comptage' à 'CountingSort' dans vos CSV.
    # Si les noms de vos colonnes CSV sont différents (par ex. 'QuickSort' au lieu de 'Rapide'), 
    # vous devez ajuster cette liste 'ALGORITHMS_TO_PLOT'.
    
    for algo in ALGORITHMS_TO_PLOT:
        plot_individual_analysis(df_best, df_worst, df_random, 
                                 algo, f'Graphe_Analyse_{algo}')

    print("\n\n✅ Génération de tous les graphiques terminée. Vérifiez le dossier 'images/'.")