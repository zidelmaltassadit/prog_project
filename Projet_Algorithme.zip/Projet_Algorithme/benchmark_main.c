// benchmark_main.c
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>

// Déclarations des fonctions de tri (assurez-vous d'inclure les .h si vous séparez les fichiers)
void bubble_sort(int *arr, int n);
void bubble_sort_shrink(int *arr, int n);
void bubble_sort_earlyexit(int *arr, int n);
void cocktail_sort(int *arr, int n);
void selection_sort(int *arr, int n);
void insertion_sort(int *arr, int n);
void counting_sort(int *arr, int n, int max_val);
void merge_sort(int *arr, int l, int r);
void quick_sort(int *arr, int low, int high);
void heap_sort(int arr[], int n);
void shell_sort(int arr[], int n);

// Wrapper pour Tri Fusion
void merge_sort_caller(int *arr, int n) { merge_sort(arr, 0, n - 1); }
// Wrapper pour Tri Rapide
void quick_sort_caller(int *arr, int n) { quick_sort(arr, 0, n - 1); }

// Définition de la structure de fonction pour le benchmark
typedef void (*SortFunc)(int *, int, int); // Utilisé pour Tri Dénombrement
typedef void (*SortFuncSimple)(int *, int); 

// --- Fonctions de Génération de Données ---

// Générer un tableau avec des valeurs aléatoires
void generate_random(int *arr, int n, int max_val) {
    for (int i = 0; i < n; i++) {
        arr[i] = rand() % (max_val + 1);
    }
}

// Générer un tableau trié
void generate_sorted(int *arr, int n) {
    for (int i = 0; i < n; i++) {
        arr[i] = i;
    }
}

// Générer un tableau trié inversé
void generate_reverse(int *arr, int n) {
    for (int i = 0; i < n; i++) {
        arr[i] = n - 1 - i;
    }
}

// Générer un tableau constant
void generate_constant(int *arr, int n) {
    for (int i = 0; i < n; i++) {
        arr[i] = 42; // Une valeur constante
    }
}

// --- Fonction Principale de Mesure ---

double time_sort(SortFuncSimple sort_func, int *data, int n) {
    // Crée une copie du tableau original pour le tri
    int *temp_arr = (int *)malloc(n * sizeof(int));
    if (temp_arr == NULL) { perror("Erreur d'allocation"); exit(EXIT_FAILURE); }
    memcpy(temp_arr, data, n * sizeof(int));

    clock_t start, end;
    start = clock();
    sort_func(temp_arr, n);
    end = clock();

    free(temp_arr);
    return ((double)(end - start)) / CLOCKS_PER_SEC;
}

// Surcharge pour Tri par Dénombrement (besoin de max_val)
double time_counting_sort(int *data, int n, int max_val) {
    int *temp_arr = (int *)malloc(n * sizeof(int));
    if (temp_arr == NULL) { perror("Erreur d'allocation"); exit(EXIT_FAILURE); }
    memcpy(temp_arr, data, n * sizeof(int));

    clock_t start, end;
    start = clock();
    counting_sort(temp_arr, n, max_val);
    end = clock();

    free(temp_arr);
    return ((double)(end - start)) / CLOCKS_PER_SEC;
}


int main() {
    srand(time(NULL));
    // Les tailles de tableau à tester
    int sizes[] = {1000, 5000, 10000, 15000, 20000, 30000, 40000, 50000};
    int num_sizes = sizeof(sizes) / sizeof(sizes[0]);
    int max_val_global = 50000; // Max pour Tri par Dénombrement

    // Nombre de répétitions pour le cas aléatoire (pour une moyenne)
    int num_repetitions = 5; 
    
    // Déclaration des tableaux de données
    int *data_base = NULL; // Tableau original non trié
    int n;

    FILE *fp_random = fopen("results_random.csv", "w");
    FILE *fp_best = fopen("results_best.csv", "w");
    FILE *fp_worst = fopen("results_worst.csv", "w");

    // Écriture des en-têtes CSV
    fprintf(fp_random, "Taille,Bulle_v1,Bulle_v2,Bulle_v3,Cocktail,Selection,Insertion,Fusion,Rapide,Comptage,Tas,Shell\n");
    fprintf(fp_best, "Taille,Bulle_v1,Bulle_v2,Bulle_v3,Cocktail,Selection,Insertion,Fusion,Rapide,Comptage,Tas,Shell\n");
    fprintf(fp_worst, "Taille,Bulle_v1,Bulle_v2,Bulle_v3,Cocktail,Selection,Insertion,Fusion,Rapide,Comptage,Tas,Shell\n");


    // Définition des algorithmes et de leurs wrappers
    SortFuncSimple algorithms[] = {
        bubble_sort, bubble_sort_shrink, bubble_sort_earlyexit, 
        cocktail_sort, selection_sort, insertion_sort, 
        merge_sort_caller, quick_sort_caller, heap_sort, shell_sort
    };
    int num_algos = 10;
    
    // Boucle principale sur les tailles
    for (int i = 0; i < num_sizes; i++) {
        n = sizes[i];
        printf("Processing size n=%d...\n", n);
        
        data_base = (int *)malloc(n * sizeof(int));

        // --- Cas Moyen (Aléatoire) ---
        double avg_times[num_algos + 1]; // +1 pour Tri Dénombrement
        for (int k = 0; k < num_algos + 1; k++) avg_times[k] = 0.0;

        for (int rep = 0; rep < num_repetitions; rep++) {
            generate_random(data_base, n, max_val_global);

            for (int j = 0; j < num_algos; j++) {
                avg_times[j] += time_sort(algorithms[j], data_base, n);
            }
            // Tri Dénombrement (indice 10)
            avg_times[10] += time_counting_sort(data_base, n, max_val_global);
        }

        fprintf(fp_random, "%d", n);
        for (int j = 0; j < num_algos + 1; j++) {
            fprintf(fp_random, ",%.8f", avg_times[j] / num_repetitions);
        }
        fprintf(fp_random, "\n");

        // --- Cas Meilleur (Croissant) ---
        generate_sorted(data_base, n);
        fprintf(fp_best, "%d", n);
        for (int j = 0; j < num_algos; j++) {
            fprintf(fp_best, ",%.8f", time_sort(algorithms[j], data_base, n));
        }
        fprintf(fp_best, ",%.8f", time_counting_sort(data_base, n, max_val_global)); // Tri Dénombrement
        fprintf(fp_best, "\n");


        // --- Cas Pire (Décroissant) ---
        generate_reverse(data_base, n);
        fprintf(fp_worst, "%d", n);
        for (int j = 0; j < num_algos; j++) {
            fprintf(fp_worst, ",%.8f", time_sort(algorithms[j], data_base, n));
        }
        fprintf(fp_worst, ",%.8f", time_counting_sort(data_base, n, max_val_global)); // Tri Dénombrement
        fprintf(fp_worst, "\n");

        free(data_base);
    }

    fclose(fp_random);
    fclose(fp_best);
    fclose(fp_worst);
    
    printf("Benchmark completed. Results saved in CSV files.\n");

    return 0;
}