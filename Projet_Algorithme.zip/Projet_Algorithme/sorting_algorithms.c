#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

// Fonction utilitaire pour échanger deux éléments
void swap(int *a, int *b) {
    int temp = *a;
    *a = *b;
    *b = temp;
}

// ----------------------------------------------------
// TRI À BULLE (3 versions)
// ----------------------------------------------------

// Tri à bulle V1 (Basique)
// Complexité: O(n^2) dans tous les cas
void bubble_sort(int *arr, int n) {
    for (int i = 0; i < n - 1; i++) {
        for (int j = 0; j < n - 1; j++) {
            if (arr[j] > arr[j + 1]) {
                swap(&arr[j], &arr[j + 1]);
            }
        }
    }
}

// Tri à bulle V2 (Optimisation de boucle - Dernier échange)
// Complexité: O(n^2) dans tous les cas
void bubble_sort_shrink(int *arr, int n) {
    for (int i = 0; i < n - 1; i++) {
        // La boucle interne s'arrête plus tôt car les i derniers sont déjà triés
        for (int j = 0; j < n - 1 - i; j++) {
            if (arr[j] > arr[j + 1]) {
                swap(&arr[j], &arr[j + 1]);
            }
        }
    }
}

// Tri à bulle V3 (Optimisation d'arrêt anticipé)
// Complexité: O(n) (Meilleur cas), O(n^2) (Pire/Moyen cas)
void bubble_sort_earlyexit(int *arr, int n) {
    int swapped;
    for (int i = 0; i < n - 1; i++) {
        swapped = 0;
        for (int j = 0; j < n - 1 - i; j++) { // Optimisation de boucle (v2) incluse
            if (arr[j] > arr[j + 1]) {
                swap(&arr[j], &arr[j + 1]);
                swapped = 1;
            }
        }
        // Arrêt anticipé: si aucun échange, le tableau est trié
        if (swapped == 0) {
            break;
        }
    }
}

// Tri cocktail (Bidirectionnel)
// Complexité: O(n) (Meilleur cas), O(n^2) (Pire/Moyen cas)
void cocktail_sort(int *arr, int n) {
    int swapped = 1;
    int start = 0;
    int end = n - 1;

    while (swapped) {
        swapped = 0;
        
        // Parcourir de gauche à droite (Tri à Bulle normal)
        for (int i = start; i < end; i++) {
            if (arr[i] > arr[i + 1]) {
                swap(&arr[i], &arr[i + 1]);
                swapped = 1;
            }
        }
        if (!swapped) break;
        swapped = 0;
        end--;

        // Parcourir de droite à gauche (déplacer les petits éléments)
        for (int i = end - 1; i >= start; i--) {
            if (arr[i] > arr[i + 1]) {
                swap(&arr[i], &arr[i + 1]);
                swapped = 1;
            }
        }
        start++;
    }
}

// Tri par sélection
// Complexité: O(n^2) dans tous les cas (nombre de comparaisons fixe)
void selection_sort(int *arr, int n) {
    int i, j, min_idx;
    for (i = 0; i < n - 1; i++) {
        min_idx = i;
        for (j = i + 1; j < n; j++) {
            if (arr[j] < arr[min_idx]) {
                min_idx = j;
            }
        }
        swap(&arr[min_idx], &arr[i]);
    }
}

// Tri par insertion
// Complexité: O(n) (Meilleur cas), O(n^2) (Pire/Moyen cas)
void insertion_sort(int *arr, int n) {
    int i, key, j;
    for (i = 1; i < n; i++) {
        key = arr[i];
        j = i - 1;
        // Déplacer les éléments plus grands vers la droite
        while (j >= 0 && arr[j] > key) {
            arr[j + 1] = arr[j];
            j = j - 1;
        }
        arr[j + 1] = key;
    }
}
// ----------------------------------------------------
// TRI FUSION (Merge Sort)
// ----------------------------------------------------

void merge(int *arr, int l, int m, int r) {
    int i, j, k;
    int n1 = m - l + 1;
    int n2 = r - m;

    int *L = (int *)malloc(n1 * sizeof(int));
    int *R = (int *)malloc(n2 * sizeof(int));

    for (i = 0; i < n1; i++) L[i] = arr[l + i];
    for (j = 0; j < n2; j++) R[j] = arr[m + 1 + j];

    i = 0; j = 0; k = l;
    while (i < n1 && j < n2) {
        if (L[i] <= R[j]) {
            arr[k] = L[i];
            i++;
        } else {
            arr[k] = R[j];
            j++;
        }
        k++;
    }

    while (i < n1) { arr[k] = L[i]; i++; k++; }
    while (j < n2) { arr[k] = R[j]; j++; k++; }

    free(L);
    free(R);
}

// Fonction récursive principale pour le Tri Fusion
// Complexité: O(n log n) dans tous les cas
void merge_sort(int *arr, int l, int r) {
    if (l < r) {
        int m = l + (r - l) / 2;
        merge_sort(arr, l, m);
        merge_sort(arr, m + 1, r);
        merge(arr, l, m, r);
    }
}

// ----------------------------------------------------
// TRI RAPIDE (Quick Sort)
// ----------------------------------------------------

// Partition avec pivot aléatoire (crucial pour le cas moyen)
int partition_random(int *arr, int low, int high) {
    // Choisir un pivot aléatoire et l'échanger avec l'élément le plus à droite
    int random_idx = low + rand() % (high - low + 1);
    swap(&arr[random_idx], &arr[high]);

    int pivot = arr[high];
    int i = (low - 1);

    for (int j = low; j <= high - 1; j++) {
        if (arr[j] <= pivot) {
            i++;
            swap(&arr[i], &arr[j]);
        }
    }
    swap(&arr[i + 1], &arr[high]);
    return (i + 1);
}

// Fonction récursive principale pour le Tri Rapide
// Complexité: O(n log n) (Moyen cas), O(n^2) (Pire cas - rare avec pivot aléatoire)
void quick_sort(int *arr, int low, int high) {
    if (low < high) {
        int pi = partition_random(arr, low, high);
        quick_sort(arr, low, pi - 1);
        quick_sort(arr, pi + 1, high);
    }
}

// ----------------------------------------------------
// TRI PAR DÉNOMBREMENT (Counting Sort)
// ----------------------------------------------------

// Complexité: O(n + k) où k est la plage de valeurs
void counting_sort(int *arr, int n, int max_val) {
    // Si la plage max_val est trop grande, ce tri n'est pas efficace
    if (max_val > 1000000 || n <= 1) return; 
    
    int *output = (int *)malloc(n * sizeof(int));
    int *count = (int *)calloc(max_val + 1, sizeof(int));

    // 1. Compter les occurrences
    for (int i = 0; i < n; i++) {
        count[arr[i]]++;
    }

    // 2. Modifier le tableau de comptage pour avoir les positions cumulées
    for (int i = 1; i <= max_val; i++) {
        count[i] += count[i - 1];
    }

    // 3. Placer les éléments dans le tableau de sortie de manière stable
    for (int i = n - 1; i >= 0; i--) {
        output[count[arr[i]] - 1] = arr[i];
        count[arr[i]]--;
    }

    // 4. Copier le tableau de sortie vers le tableau original
    memcpy(arr, output, n * sizeof(int));

    free(output);
    free(count);
}

// ----------------------------------------------------
// TRI PAR TAS (Heap Sort) - BONUS
// ----------------------------------------------------

void heapify(int arr[], int n, int i) {
    int largest = i;
    int l = 2 * i + 1;
    int r = 2 * i + 2;

    if (l < n && arr[l] > arr[largest]) largest = l;
    if (r < n && arr[r] > arr[largest]) largest = r;
    
    if (largest != i) {
        swap(&arr[i], &arr[largest]);
        heapify(arr, n, largest);
    }
}

// Complexité: O(n log n) dans tous les cas
void heap_sort(int arr[], int n) {
    for (int i = n / 2 - 1; i >= 0; i--) heapify(arr, n, i);
    for (int i = n - 1; i > 0; i--) {
        swap(&arr[0], &arr[i]);
        heapify(arr, i, 0);
    }
}

// ----------------------------------------------------
// TRI SHELL (Shell Sort) - BONUS
// ----------------------------------------------------

// Complexité: Dépend de la séquence d'écarts (gap) - Typiquement O(n log^2 n) ou mieux
void shell_sort(int arr[], int n) {
    for (int gap = n / 2; gap > 0; gap /= 2) {
        for (int i = gap; i < n; i++) {
            int temp = arr[i];
            int j;
            for (j = i; j >= gap && arr[j - gap] > temp; j -= gap) {
                arr[j] = arr[j - gap];
            }
            arr[j] = temp;
        }
    }
}